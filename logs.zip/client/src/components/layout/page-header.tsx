import NotificationBell from "@/components/notifications/notification-bell";

export default function PageHeader() {
  return (
    <NotificationBell />
  );
}
